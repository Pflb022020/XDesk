Action()
{
	char* VtsServer = "192.168.14.62";
	int Port = 3999;
	int rc;
	int shopNumber;
	
	shopNumber = rand()%2 + 1;
	
	lr_save_int(shopNumber, "shopnumber1");
	
	lr_save_string("engineer", "log");
	lr_save_string("123", "pass");
	lr_save_string("192.168.14.54", "adr");
	lr_save_string("9433", "por");

	lr_start_transaction("UC01_T01_Entrance");

	lr_think_time(3);

	web_url("{adr}:{por}", 
		"URL=http://{adr}:{por}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML");

	/* Request with GET method to URL "http://{adr}:{por}/api/checkLogin" failed during recording. Server response : 401*/

	web_url("login", 
		"URL=http://{adr}:{por}/login", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{adr}:{por}/", 
		"Snapshot=t4.inf", 
		"Mode=HTML");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_url("query", 
		"URL=https://af.opera.com/api/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZqF7MbI5xi8cjLShLLYkkIy3OQUx6JBQ=", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T01_Entrance",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("UC01_T02_Logging_in");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_add_header("Origin", 
		"http://{adr}:{por}");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(4);

	web_submit_data("login_2", 
		"Action=http://{adr}:{por}/api/login", 
		"Method=POST", 
		"TargetFrame=", 
		"Referer=http://{adr}:{por}/login", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value=engineer", ENDITEM, 
		"Name=password", "Value=123", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);

	lr_end_transaction("UC01_T02_Logging_in",LR_AUTO);
	
	lr_start_transaction("UC01_T03_Creating_an_accident");
	
	web_reg_save_param_json(
		"ParamName=Defekt",
        "QueryString=$..parentName",
        "SelectAll=Yes",
        "SEARCH_FILTERS",
        "Scope=Body",
        "LAST");
	
	web_reg_save_param_json(
		"ParamName=id",
        "QueryString=$..services..id",
        "SelectAll=Yes",
        "SEARCH_FILTERS",
        "Scope=Body",
        "LAST");

	web_url("/api/user/catalog/treeview", 
		"URL=http://{adr}:{por}/api/user/catalog/treeview?shopid=1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t228.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T03_Creating_an_accident", LR_AUTO);
	
	lr_save_string(lr_eval_string(lr_paramarr_random("Defekt")), "Defekt1");
	lr_save_string(lr_eval_string(lr_paramarr_random("id")), "id1");

	web_url("{adr}:{por}_2",
		"URL=http://{adr}:{por}/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{adr}:{por}/login", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/js/core/jqueryformplugin.js?_=1582276721331", ENDITEM, 
		"Url=/api/checkLogin", ENDITEM, 
		"Url=/api/user/info", ENDITEM, 
		"Url=/engineer/wrapper/wrapper.dust", ENDITEM, 
		"Url=/engineer/wrapper/wrapper.js", ENDITEM, 
		"Url=/engineer/tickets/tickets.dust", ENDITEM, 
		"Url=/engineer/tickets/tickets.js", ENDITEM, 
		"Url=/api/ticket/countByState/", ENDITEM, 
		"Url=/api/ticket/?state=-1,0,1,5&page=0&size=10", ENDITEM, 
		"Url=/engineer/catalog/catalog.dust", ENDITEM, 
		"Url=/engineer/catalog/catalog.js", ENDITEM, 
		"Url=/api/user/catalog/node/0/children/", ENDITEM, 
		"Url=/images/logo-5ka.png", ENDITEM, 
		"Url=/api/shops?q=&page=0", ENDITEM, 
		"Url=/api/user/catalog/treeview?shopid=1", ENDITEM, 
		"Url=/api/user/catalog/node/207/children/", ENDITEM, 
		"Url=/api/user/catalog/node/207/service/", ENDITEM, 
		"Url=/api/user/catalog/breadcrumbs/207", ENDITEM, 
		"Url=/engineer/addticket.dust", ENDITEM, 
		"Url=/api/inventoryNumbers?serviceId=2995&shopId=1", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("4", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	
	lr_start_transaction("UC01_T06_Description_and_approving");

	lr_think_time(3);

	web_reg_save_param_ex(
		"ParamName=dataid",
		"LB=id\":",
		"RB=,\"ap",
		SEARCH_FILTERS,
		LAST);
	
	web_custom_request("ticket", 
		"URL=http://192.168.14.54:9433/api/ticket/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"BodyBinary={\"text\":\"Lol\",\"header\":\"{Defekt1}\",\"ticketStateId\":0,\"serviceId\":\"{id1}\",\"files\":[],\"inventoryNumberId\":null,\"shopId\":\"{shopnumber1}\"}", 
		LAST);

	lr_log_message(lr_eval_string("{dataid} �������"));

	rc = lrvtc_connect(VtsServer, Port, VTOPT_KEEP_ALIVE);
	rc = lrvtc_send_message("New", "{dataid}");

	rc = lrvtc_disconnect();

	lr_end_transaction("UC01_T06_Description_and_approving",LR_AUTO);

	return 0;
}