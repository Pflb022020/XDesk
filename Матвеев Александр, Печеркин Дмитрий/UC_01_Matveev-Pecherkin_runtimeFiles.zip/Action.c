Action()
{
	char* VtsServer = "192.168.14.62";
	int Port = 3999;
	int rc;
	
	lr_start_transaction("UC01_T01_Entrance");

	lr_think_time(3);

	web_url("{adr}:{por}", 
		"URL=http://{adr}:{por}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML");

	web_url("login", 
		"URL=http://{adr}:{por}/login", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{adr}:{por}/", 
		"Snapshot=t4.inf", 
		"Mode=HTML");

	lr_end_transaction("UC01_T01_Entrance",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("UC01_T02_Logging_in");

	lr_think_time(4);

	web_submit_data("login_2", 
		"Action=http://{adr}:{por}/api/login", 
		"Method=POST", 
		"TargetFrame=", 
		"Referer=http://{adr}:{por}/login", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={log}", ENDITEM, 
		"Name=password", "Value={pass}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);

	lr_end_transaction("UC01_T02_Logging_in",LR_AUTO);
	
	lr_start_transaction("UC01_T03_Creating_an_accident");
	
	web_reg_save_param_json(
		"ParamName=Defekt",
        "QueryString=$..parentName",
        "SelectAll=Yes",
        "SEARCH_FILTERS",
        "Scope=Body",
        "LAST");
	
	web_reg_save_param_json(
		"ParamName=id",
        "QueryString=$..services..id",
        "SelectAll=Yes",
        "SEARCH_FILTERS",
        "Scope=Body",
        "LAST");

	web_url("/api/user/catalog/treeview", 
		"URL=http://{adr}:{por}/api/user/catalog/treeview?shopid=1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t228.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T03_Creating_an_accident", LR_AUTO);
	
	lr_save_string(lr_eval_string(lr_paramarr_random("Defekt")), "Defekt1");
	lr_save_string(lr_eval_string(lr_paramarr_random("id")), "id1");

	web_url("{adr}:{por}_2",
		"URL=http://{adr}:{por}/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{adr}:{por}/login", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4", 
		"URL=http://{adr}:{por}/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{adr}:{por}/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	
	lr_start_transaction("UC01_T06_Description_and_approving");

	lr_think_time(3);

	web_reg_save_param_ex(
		"ParamName=dataid",
		"LB=id\":",
		"RB=,\"ap",
		SEARCH_FILTERS,
		LAST);
	
	web_custom_request("ticket", 
		"URL=http://{adr}:{por}/api/ticket/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{adr}:{por}/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"BodyBinary={\"text\":\"Lol\",\"header\":\"{Defekt1}\",\"ticketStateId\":0,\"serviceId\":\"{id1}\",\"files\":[],\"inventoryNumberId\":null,\"shopId\":\"{shopnumber1}\"}", 
		LAST);

	lr_log_message(lr_eval_string("{dataid} �������"));

	rc = lrvtc_connect(VtsServer, Port, VTOPT_KEEP_ALIVE);
	rc = lrvtc_send_message("New", "{dataid}");

	rc = lrvtc_disconnect();

	lr_end_transaction("UC01_T06_Description_and_approving",LR_AUTO);

	return 0;
}