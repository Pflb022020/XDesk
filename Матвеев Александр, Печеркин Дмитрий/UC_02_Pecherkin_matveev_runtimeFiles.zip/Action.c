Action()
{
	lr_start_transaction("UC02_homepage");

		web_url("/login", 
			"URL=http://{host}:{port}/login", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Snapshot=t1.inf", 
			"Mode=HTML", 
			LAST);
	lr_end_transaction("UC02_homepage",LR_AUTO);
		
	lr_start_transaction("UC02_login");

		web_submit_data("/api/login", 
			"Action=http://{host}:{port}/api/login", 
			"Method=POST", 
			"Snapshot=t2.inf", 
			"Mode=HTML", 
			ITEMDATA, 
			"Name=login", "Value={login}", ENDITEM, 
			"Name=password", "Value={password}", ENDITEM, 
			"Name=rememberMe", "Value=false", ENDITEM, 
			LAST);
	
		web_url("/", 
			"URL=http://{host}:{port}", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Snapshot=t3.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/checkLogin", 
			"URL=http://{host}:{port}/api/checkLogin", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t4.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/user/info", 
			"URL=http://{host}:{port}/api/user/info", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t5.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/ticket/countByState/4", 
			"URL=http://{host}:{port}/api/ticket/countByState/4", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t6.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/ticket/countByState/", 
			"URL=http://{host}:{port}/api/ticket/countByState/", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t7.inf", 
			"Mode=HTML", 
			LAST);
	
		web_custom_request("/api/ticket/", 
			"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
			"Method=GET", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t8.inf", 
			"Mode=HTML", 
			"EncType=application/json; charset=utf-8", 
			LAST);

	lr_end_transaction("UC02_login",LR_AUTO);

	lr_start_transaction("UC02_incident");

		web_url("/api/task/countByState/", 
			"URL=http://{host}:{port}/api/task/countByState/", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t9.inf", 
			"Mode=HTML", 
			LAST);
	
		web_reg_save_param_json(
			"ParamName=id_taskRow",
			"QueryString=$.content[:].id",
			"SelectAll=Yes",
			SEARCH_FILTERS,
			LAST);
	
		
		web_custom_request("/api/task/", 
			"URL=http://{host}:{port}/api/task/?state=1&page=0&size=2000", 
			"Method=GET", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t10.inf", 
			"Mode=HTML", 
			"EncType=application/json; charset=utf-8", 
			LAST);
	
		lr_param_sprintf("task_id","%s",lr_paramarr_random("id_taskRow"));
		
		web_url("/api/task/", 
			"URL=http://{host}:{port}/api/task/{task_id}", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t11.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/checkLogin", 
			"URL=http://{host}:{port}/api/checkLogin", 
			"Resource=0", 
			"RecContentType=application/json",  
			"Snapshot=t12.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/ticket/", 
			"URL=http://{host}:{port}/api/ticket/{task_id}/comment/", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t13.inf", 
			"Mode=HTML", 
			LAST);

	lr_end_transaction("UC02_incident",LR_AUTO);

	lr_start_transaction("UC02_comment");

		web_custom_request("/api/ticket/", 
			"URL=http://{host}:{port}/api/ticket/{task_id}/comment/", 
			"Method=POST", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t14.inf", 
			"Mode=HTML", 
			"EncType=application/json; charset=UTF-8", 
			"Body={\"text\":\"{comment}\",\"files\":[]}", 
			LAST);
	
		web_url("/api/ticket/", 
			"URL=http://{host}:{port}/api/ticket/{task_id}/comment/", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t15.inf", 
			"Mode=HTML", 
			LAST);

	lr_end_transaction("UC02_comment",LR_AUTO);
	
	lr_start_transaction("UC02_logout");

		web_url("/api/logout", 
			"URL=http://{host}:{port}/api/logout", 
			"TargetFrame=", 
			"Resource=0", 
			"Snapshot=t16.inf", 
			"Mode=HTML", 
			LAST);
	lr_end_transaction("UC02_logout",LR_AUTO);
	return 0;
}
