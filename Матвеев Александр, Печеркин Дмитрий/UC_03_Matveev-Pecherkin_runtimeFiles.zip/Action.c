Action()
{

	lr_start_transaction("UC03_T01_Entrance");

	web_submit_data("login_2", 
		"Action=http://{adr}:{por}/api/login", 
		"Method=POST", 
		"TargetFrame=", 
		"Referer=http://{adr}:{por}/login", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={log}", ENDITEM, 
		"Name=password", "Value={pass}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);
	
	web_reg_save_param_json(
		"ParamName=Tasks",
        "QueryString=$..taskId",
        "SelectAll=Yes",
        "SEARCH_FILTERS",
        "Scope=Body",
        "LAST");
	
	web_url("web_url",
		"URL=http://{adr}:{por}/api/ticket/?state=0,1,5&page=0&size=20",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		LAST);
	
	lr_save_string(lr_eval_string(lr_paramarr_random("Tasks")), "kekus");
	lr_log_message(lr_eval_string("{kekus}"));
	
	web_url("192.168.14.54:9433_2", 
		"URL=http://{adr}:{por}/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{adr}:{por}/login", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4", 
		"URL=http://{adr}:{por}/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{adr}:{por}/", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	
	lr_end_transaction("UC03_T01_Entrance",LR_AUTO);

	lr_start_transaction("UC03_T03_Going_to_tasks_list");

	web_custom_request("solve", 
		"URL=http://{adr}:{por}/api/ticket/{kekus}/solve/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{adr}:{por}/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("{adr}:{por}_3", 
		"URL=http://{adr}:{por}/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{adr}:{por}/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4_2", 
		"URL=http://{adr}:{por}/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{adr}:{por}/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_T03_Going_to_tasks_list",LR_AUTO);

	return 0;
}