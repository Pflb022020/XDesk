Action()
{

	lr_start_transaction("UC03_T01_Entrance");

	web_submit_data("UC03_T01_Entrance_api/login", 
		"Action=http://{adr}:{por}/api/login", 
		"Method=POST", 
		"TargetFrame=", 
		"Referer=http://{adr}:{por}/login", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={log}", ENDITEM, 
		"Name=password", "Value={pass}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);
	
	web_reg_save_param_json(
		"ParamName=Tasks",
        "QueryString=$..taskId",
        "SelectAll=Yes",
        "SEARCH_FILTERS",
        "Scope=Body",
        "LAST");
	
	web_url("UC03_T01_Entrance_api/ticket/?state=0,1,5&page=0&size=20",
		"URL=http://{adr}:{por}/api/ticket/?state=0,1,5&page=0&size=20",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		LAST);
	
	lr_save_string(lr_eval_string(lr_paramarr_random("Tasks")), "kekus");
	lr_log_message(lr_eval_string("{kekus}"));
	
	web_url("UC03_T01_Entrance", 
		"URL=http://{adr}:{por}/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{adr}:{por}/login", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_url("UC03_T01_Entrance_api/ticket/countByState/4", 
		"URL=http://{adr}:{por}/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{adr}:{por}/", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	
	lr_end_transaction("UC03_T01_Entrance",LR_AUTO);

	lr_start_transaction("UC03_T03_Going_to_tasks_list");

	web_custom_request("UC03_T03_Going_to_tasks_list_api/ticket/{kekus}/solve/", 
		"URL=http://{adr}:{por}/api/ticket/{kekus}/solve/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{adr}:{por}/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("UC03_T03_Going_to_task_index.html", 
		"URL=http://{adr}:{por}/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{adr}:{por}/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		LAST);

	web_url("UC03_T03_Going_to_task_api/ticket/countByState/4", 
		"URL=http://{adr}:{por}/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{adr}:{por}/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_T03_Going_to_tasks_list",LR_AUTO);

	return 0;
}