//@author: Dmitry Konov

Action()
{
	char* VtsServer = "192.168.14.62";
	int nPort = 3999;
	int rc;

	lr_start_transaction("UC01_T01_Entrace");

	web_url("login", 
		"URL=http://{host}:{port}/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML",
		LAST);
	
	lr_end_transaction("UC01_T01_Entrace", LR_AUTO);

	//------------------------------------------------------------------------------------
	
	lr_start_transaction("UC01_T02_Logging_in");

	lr_think_time(8);

	web_submit_data("login_2", 
		"Action=http://{host}:{port}/api/login", 
		"Method=POST", 
		"Referer=http://{host}:{port}/login", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value=engineer", ENDITEM, 
		"Name=password", "Value=123", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);

	web_url("{host}:{port}", 
		"URL=http://{host}:{port}/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{host}:{port}/login", 
		"Snapshot=t7.inf", 
		"Mode=HTML",
		LAST);

	web_url("checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("info", 
		"URL=http://{host}:{port}/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"Resource=0", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);
		
	web_custom_request("ticket", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC01_T02_Logging_in",LR_AUTO);
	
	//------------------------------------------------------------------------------------

	lr_start_transaction("UC01_T03_Creating_of_new_accident");

	web_url("children", 
		"URL=http://{host}:{port}/api/user/catalog/node/0/children/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T03_Creating_of_new_accident",LR_AUTO);
	
	//------------------------------------------------------------------------------------

	lr_think_time(5);

	lr_start_transaction("UC01_T04_Address_of_accident");

	web_url("shops", 
		"URL=http://{host}:{port}/api/shops?q=&page=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_url("children_2", 
		"URL=http://{host}:{port}/api/user/catalog/node/0/children/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);
	
	web_reg_save_param_json(
		"ParamName=header_text",
        "QueryString=$..parentName",
        "SelectAll=Yes",
        "SEARCH_FILTERS",
        "Scope=Body",
        "LAST");
	
	web_reg_save_param_json(
		"ParamName=id",
        "QueryString=$..services..id,
        "SelectAll=Yes",
        "SEARCH_FILTERS",
        "Scope=Body",
        "LAST");
	
	web_url("treeview", 
		"URL=http://{host}:{port}/api/user/catalog/treeview?shopid=2", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T04_Address_of_accident",LR_AUTO);
	
	lr_save_string(lr_paramarr_random("header_text"),"random_header_text");
	
	
	//��������
	lr_paramarr_idx()
	
	//------------------------------------------------------------------------------------

	lr_start_transaction("UC01_T05_Choose_of_type_accident");
	
	

	web_url("children_3", 
		"URL=http://{host}:{port}/api/user/catalog/node/179/children/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_url("service", 
		"URL=http://{host}:{port}/api/user/catalog/node/179/service/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_url("179", 
		"URL=http://{host}:{port}/api/user/catalog/breadcrumbs/179", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_url("inventoryNumbers", 
		"URL=http://{host}:{port}/api/inventoryNumbers?serviceId=2881&shopId=2", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t20.inf", 
		"Mode=HTML",
		LAST);

	lr_end_transaction("UC01_T05_Choose_of_type_accident",LR_AUTO);
	
	//------------------------------------------------------------------------------------

	lr_start_transaction("UC01_T06_ Description_and_approving");

	lr_think_time(12);

	web_custom_request("ticket_2", 
		"URL=http://{host}:{port}/api/ticket/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"BodyBinary={\"text\":\"Accident\",\"header\":\"{random_header_text}\",\"ticketStateId\":0,\"serviceId\":\"3195\",\"files\":[],\"inventoryNumberId\":null,\"shopId\":\"2\"}", 
		LAST);

	web_url("{host}:{port}_2", 
		"URL=http://{host}:{port}/", 
		"Resource=0", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/js/core/jqueryformplugin.js?_=1582188173763", ENDITEM, 
		"Url=/engineer/wrapper/wrapper.dust", ENDITEM, 
		"Url=/engineer/wrapper/wrapper.js", ENDITEM, 
		"Url=/engineer/tickets/tickets.dust", ENDITEM, 
		"Url=/engineer/tickets/tickets.js", ENDITEM, 
		LAST);

	web_url("checkLogin_2", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_url("info_2", 
		"URL=http://{host}:{port}/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4_2", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"Resource=0", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState_2", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState_3", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("ticket_3", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	web_reg_save_param_json("ParamName=ID_FINAL",
        "QueryString=$.content[0].id",
        "SEARCH_FILTERS",
        "Scope=Body",
        "LAST");
	
	web_custom_request("ticket_4", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC01_T06_ Description_and_approving",LR_AUTO);
	
	//------------------------------------------------------------------------------------
	
	rc = lrvtc_connect(VtsServer, nPort, VTOPT_KEEP_ALIVE);
	rc = lrvtc_send_message("New", "{ID_FINAL}");
	rc = lrvtc_disconnect();

	return 0;
}