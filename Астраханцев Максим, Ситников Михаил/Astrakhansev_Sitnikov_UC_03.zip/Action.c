Action()
{
	
	lr_start_transaction("UC03_T01_Entrance");

	web_url("/login", 
		"URL=http://{ip}:{port}/login",  
		"Snapshot=t1.inf",  
		LAST);

	lr_end_transaction("UC03_T01_Entrance",LR_AUTO);
	
	
	
	
	
	lr_start_transaction("UC03_T02_Logging_in");
	
	web_submit_data("/api/login", 
		"Action=http://{ip}:{port}/api/login", 
		"Method=POST",  
		"Snapshot=t2.inf",  
		ITEMDATA, 
		"Name=login", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);
	
	web_url("host_ip:port/", 
		"URL=http://{ip}:{port}/",  
		"Snapshot=t3.inf", 
		LAST);
	
	lr_end_transaction("UC03_T02_Logging_in",LR_AUTO);
	
	
	
	
	
	
	web_reg_save_param_regexp(
		"ParamName=id",
		"RegExp={\"id\":(\\d\{6\})",
		"Group=1",
		"Ordinal=ALL",
		SEARCH_FILTERS,
		LAST);
	
	
	
	
	

	lr_start_transaction("UC03_T03_Going_to_tasks_list");
	
	web_custom_request("/api/ticket/?state=1&page=0&size=10", 
		"URL=http://{ip}:{port}/api/ticket/?state=1&page=0&size=10", 
		"Snapshot=t4.inf",  
		LAST);
	
	lr_end_transaction("UC03_T03_Going_to_tasks_list",LR_AUTO);
	
	
	
	lr_save_string(lr_paramarr_random("id"), "idCur");
	
	
	
	lr_start_transaction("UC03_T04_Picking_a_task");
	
	
	
	

	web_custom_request("/api/ticket/....", 
		"URL=http://{ip}:{port}/api/ticket/{idCur}", 
		"Snapshot=t5.inf", 
		LAST);
	
	lr_end_transaction("UC03_T04_Picking_a_task",LR_AUTO);
	
	
	
	
	
	
	

	

	lr_start_transaction("UC03_T05_Approving_completion");

	web_custom_request("/api/ticket/..../solve/", 
		"URL=http://{ip}:{port}/api/ticket/{idCur}/solve/", 
		"Method=POST",  
		"Snapshot=t6.inf", 
		LAST);
	
	lr_end_transaction("UC03_T05_Approving_completion",LR_AUTO);
	
	
	
	
	

	
	lr_start_transaction("UC03_�06_Logout");

	web_url("/api/logout", 
		"URL=http://{ip}:{port}/api/logout", 
		"Resource=0", 
		"Snapshot=t7.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("/login", 
		"URL=http://{ip}:{port}/login", 
		"Resource=0", 
		"RecContentType=text/html",  
		"Snapshot=t8.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("UC03_�06_Logout",LR_AUTO);

	return 0;
}