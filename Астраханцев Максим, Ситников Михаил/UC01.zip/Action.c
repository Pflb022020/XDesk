Action()
{
	unsigned int num;
	
	lr_start_transaction("UC01_T01_Entrance");
	
	web_url("login", 
		"URL=http://{host}:{port}/login", 
		"Snapshot=t1.inf", 
		LAST);

	lr_end_transaction("UC01_T01_Entrance",LR_AUTO);
/////////////////////////////////////////////////////////////
	lr_start_transaction("UC01_T02_Logging_in");

	web_submit_data("login_2", 
		"Action=http://{host}:{port}/api/login", 
		"Method=POST", 
		"Snapshot=t2.inf", 
		ITEMDATA, 
		"Name=login", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);

	web_url("/", 
		"URL=http://{host}:{port}/", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("info", 
		"URL=http://{host}:{port}/api/user/info", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("4", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("countByState", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Snapshot=t7.inf", 
		LAST);

	web_custom_request("ticket", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Snapshot=t8.inf", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC01_T02_Logging_in",LR_AUTO);
//////////////////////////////////////////////////////////////////////////////////
	lr_start_transaction("UC01_T03_Creating_of_new_accident");

	web_url("children", 
		"URL=http://{host}:{port}/api/user/catalog/node/0/children/", 
		"Snapshot=t9.inf", 
		LAST);

	lr_end_transaction("UC01_T03_Creating_of_new_accident",LR_AUTO);
////////////////////////////////////////////////////////////////////////////////
	lr_think_time(5);
///////////////////////////////////////////////////////////////////////////////
	lr_start_transaction("UC01_T04_Address_of_accident");

	web_url("shops", 
		"URL=http://{host}:{port}/api/shops?q=&page=0", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("children_2", 
		"URL=http://{host}:{port}/api/user/catalog/node/0/children/", 
		"Snapshot=t12.inf", 
		LAST);
	
	web_reg_save_param_json(
		"ParamName=header",
		"QueryString=$..parentName",
		"SelectAll=Yes",
		SEARCH_FILTERS,
		LAST);
	web_reg_save_param_json(
		"ParamName=id",
		"QueryString=$..services..id",
		"SelectAll=Yes",
		SEARCH_FILTERS,
		LAST);
	web_url("treeview", 
		"URL=http://{host}:{port}/api/user/catalog/treeview?shopid=2", 
		"Snapshot=t13.inf", 
		LAST);

	lr_end_transaction("UC01_T04_Address_of_accident",LR_AUTO);
///////////////////////////////////////////////////////////////////////////////
	lr_start_transaction("UC01_T05_Choose_of_type_accident");

	web_url("children_3", 
		"URL=http://{host}:{port}/api/user/catalog/node/151/children/", 
		"Snapshot=t14.inf", 
		LAST);

	web_url("service", 
		"URL=http://{host}:{port}/api/user/catalog/node/151/service/", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("151", 
		"URL=http://{host}:{port}/api/user/catalog/breadcrumbs/151", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("inventoryNumbers", 
		"URL=http://{host}:{port}/api/inventoryNumbers?serviceId=2814&shopId=2", 
		"Snapshot=t17.inf", 
		LAST);

	lr_end_transaction("UC01_T05_Choose_of_type_accident",LR_AUTO);
//////////////////////////////////////////////////////////////////////////////////////
	lr_think_time(5);
	
	num = rand() % lr_paramarr_len("id");
	lr_save_string(lr_paramarr_idx("header", num), "headercur");
	lr_save_string(lr_paramarr_idx("id", num), "idcur");
/////////////////////////////////////////////////////////////////////////////////////
	lr_start_transaction("UC01_T06_ Description_and_approving");
	
	web_custom_request("ticket_2", 
		"URL=http://{host}:{port}/api/ticket/", 
		"Method=POST", 
		"Snapshot=t18.inf", 
		"EncType=application/json; charset=utf-8", 
		"BodyBinary={\"text\":\"Help me!\",\"header\":\" {headercur}\",\"ticketStateId\":0,\"serviceId\":\"{idcur}\",\"files\":[],\"inventoryNumberId\":null,\"shopId\":\"{ShopID}\"}", 
		LAST);

	web_url("{host}:{port}_2", 
		"URL=http://{host}:{port}/", 
		"Snapshot=t19.inf", 
		LAST);

	web_url("checkLogin_2", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Snapshot=t20.inf", 
		LAST);

	web_url("info_2", 
		"URL=http://{host}:{port}/api/user/info", 
		"Snapshot=t21.inf", 
		LAST);

	web_url("4_2", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"Snapshot=t22.inf", 
		LAST);

	web_url("countByState_2", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Snapshot=t23.inf", 
		LAST);

	web_url("countByState_3", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Snapshot=t24.inf", 
		LAST);

	web_custom_request("ticket_3", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Snapshot=t25.inf", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	web_custom_request("ticket", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Snapshot=t26.inf", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC01_T06_ Description_and_approving",LR_AUTO);
////////////////////////////////////////////////////////////////////////////////
	lr_think_time(5);
////////////////////////////////////////////////////////////////////////////////
	lr_start_transaction("UC01_T07_ Logging_out");

	web_url("logout", 
		"URL=http://{host}:{port}/api/logout", 
		"Snapshot=t27.inf", 
		LAST);
	
	lr_end_transaction("UC01_T07_ Logging_out",LR_AUTO);

	return 0;
}