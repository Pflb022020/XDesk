UC02_T05_Logging_out()
{
	
	lr_start_transaction("UC02_T05_Logging_out");

	web_url("api/logout", 
		"URL=http://{host}:{port}/api/logout", 
		"Snapshot=t17.inf", 
		LAST);

	lr_end_transaction("UC02_T05_Logging_out",LR_AUTO);

	return 0;
}
