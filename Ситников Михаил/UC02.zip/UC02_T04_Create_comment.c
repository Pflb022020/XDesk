UC02_T04_Create_comment()
{
	lr_start_transaction("UC02_T04_Create_comment");

	web_custom_request("api/ticket/{idCur}/comment", 
		"URL=http://{host}:{port}/api/ticket/{idCur}/comment/", 
		"Method=POST", 
		"Snapshot=t15.inf", 
		"EncType=application/json; charset=UTF-8", 
		"Body={\"text\":\"Any very cool coment!!\",\"files\":[]}", 
		LAST);

	web_url("api/ticket/{idCur}/comment", 
		"URL=http://{host}:{port}/api/ticket/{idCur}/comment/", 
		"Snapshot=t16.inf", 
		LAST);

	lr_end_transaction("UC02_T04_Create_comment",LR_AUTO);
	
	return 0;
}
