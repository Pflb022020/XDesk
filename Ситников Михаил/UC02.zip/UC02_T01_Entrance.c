UC02_T01_Entrance()
{
	
	lr_start_transaction("UC02_T01_Entrance");
	
	web_url("/", 
		"URL=http://{host}:{port}/", 
		"Snapshot=t1.inf", 
		LAST);

	web_url("login", 
		"URL=http://{host}:{port}/login", 
		"Snapshot=t2.inf", 
		LAST);

	lr_end_transaction("UC02_T01_Entrance",LR_AUTO);

	return 0;
}
