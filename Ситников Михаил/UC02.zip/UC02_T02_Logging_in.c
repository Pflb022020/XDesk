UC02_T02_Logging_in()
{
	lr_start_transaction("UC02_T02_Logging_in");

	web_submit_data("api/login",
		"Action=http://{host}:{port}/api/login", 
		"Method=POST", 
		"Snapshot=t3.inf", 
		ITEMDATA, 
		"Name=login", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);

	web_url("/",
		"URL=http://{host}:{port}/", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("api/user/info", 
		"URL=http://{host}:{port}/api/user/info", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("api/ticket/countByState/4", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("api/ticket/countByState", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Snapshot=t8.inf", 
		LAST);

	web_custom_request("api/ticket", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Snapshot=t9.inf", 
		"EncType=application/json; charset=utf-8", 
		LAST);
	
	lr_end_transaction("UC02_T02_Logging_in",LR_AUTO);

	return 0;
}
