UC02_T03_Choose_incident()
{
	lr_start_transaction("UC02_T03_Choose_incident");

	web_url("api/task/countByState", 
		"URL=http://{host}:{port}/api/task/countByState/", 
		"Snapshot=t10.inf", 
		LAST);

	web_reg_save_param_regexp( 
		"ParamName=id", 
		"RegExp={\"id\":(\\d\{6\})", 
		"Group=1", 
		"Ordinal=ALL", 
		SEARCH_FILTERS, 
		LAST);
	
	web_custom_request("api/task", 
		"URL=http://{host}:{port}/api/task/?state=1&page=0&size=10", 
		"Method=GET", 
		"Snapshot=t11.inf", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_save_string(lr_paramarr_random("id"), "idCur");
	
	web_url("api/task/{idCur}", 
		"URL=http://{host}:{port}/api/task/{idCur}", 
		"Snapshot=t12.inf", 
		LAST);

	web_url("api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Snapshot=t13.inf", 
		LAST);

	web_url("api/ticket/{idCur}/comment", 
		"URL=http://{host}:{port}/api/ticket/{idCur}/comment/", 
		"Snapshot=t14.inf", 
		LAST);

	lr_end_transaction("UC02_T03_Choose_incident",LR_AUTO);
	
	return 0;
}
