﻿Action()
{
	char* VtsServer = "192.168.14.62";
	int nPort = 3999;
	int rc;
	int num = -1;
	
	web_url("/login", 
		"URL=http://{host}:{port}/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t5.inf", 
		"Mode=HTML",
		LAST);

	lr_start_transaction("UC01_T02_Logging_in");

	web_submit_data("/api/login", 
		"Action=http://{host}:{port}/api/login", 
		"Method=POST", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);

	web_url("{host}:{port}", 
		"URL=http://{host}:{port}/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t7.inf", 
		"Mode=HTML",
		LAST);

	web_url("/api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/user/info", 
		"URL=http://{host}:{port}/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/4", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"Resource=0", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("/api/ticket", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		EXTRARES,
		LAST);

	lr_end_transaction("UC01_T02_Logging_in",LR_AUTO);

	lr_start_transaction("UC01_T03_Creating_of_new_accident");

	web_url("/api/user/catalog/node/0/children/", 
		"URL=http://{host}:{port}/api/user/catalog/node/0/children/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T03_Creating_of_new_accident",LR_AUTO);

	lr_think_time(23);

	lr_start_transaction("UC01_T04_Address_of_accident");

	web_reg_save_param_json(
		"ParamName=addressid",
		"QueryString=$..id",
		"SelectAll=Yes",
		SEARCH_FILTERS,
		LAST);
	
	web_url("/api/shops", 
		"URL=http://{host}:{port}/api/shops?q=&page=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_save_string(lr_paramarr_random("addressid"), "addressidr");

	web_url("/api/user/catalog/node/0/children/", 
		"URL=http://{host}:{port}/api/user/catalog/node/0/children/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);
	
	web_reg_save_param_json(
		"ParamName=case",
		"QueryString=$..parentName",
		"SelectAll=Yes",
		SEARCH_FILTERS,
		LAST);
	
	web_reg_save_param_json(
		"ParamName=id",
		"QueryString=$..services..id",
		"SelectAll=Yes",
		SEARCH_FILTERS,
		LAST);
		
	
	web_url("/api/user/catalog/treeview", 
		"URL=http://{host}:{port}/api/user/catalog/treeview?shopid=2", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);
	
	num = rand() % lr_paramarr_len("id");
	
	lr_save_string(lr_paramarr_idx("case", num), "caser");

	lr_save_string(lr_paramarr_idx("id", num), "idr");

	lr_end_transaction("UC01_T04_Address_of_accident",LR_AUTO);

	lr_start_transaction("UC01_T05_Choose_of_type_accident");

	web_url("/api/user/catalog/node/179/children", 
		"URL=http://{host}:{port}/api/user/catalog/node/179/children/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/user/catalog/node/179/service/", 
		"URL=http://{host}:{port}/api/user/catalog/node/179/service/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/user/catalog/breadcrumbs/179", 
		"URL=http://{host}:{port}/api/user/catalog/breadcrumbs/179", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/inventoryNumbers", 
		"URL=http://{host}:{port}/api/inventoryNumbers?serviceId=2881&shopId=2", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t20.inf", 
		"Mode=HTML", LAST);

	lr_end_transaction("UC01_T05_Choose_of_type_accident",LR_AUTO);

	lr_think_time(12);
	
	lr_start_transaction("UC01_T06_ Description_and_approving");

	web_custom_request("/api/ticket/", 
		"URL=http://{host}:{port}/api/ticket/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"BodyBinary={\"text\":\"{text}\",\"header\":\"{caser}\",\"ticketStateId\":0,\"serviceId\":\"{idr}\",\"files\":[],\"inventoryNumberId\":null,\"shopId\":\"{addressidr}\"}", 
		LAST);

	web_url("{host}:{port}_2", 
		"URL=http://{host}:{port}/", 
		"Resource=0", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/user/info", 
		"URL=http://{host}:{port}/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/4", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"Resource=0", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/",
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("/api/ticket/", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	web_reg_save_param_ex(
		"ParamName=ID_FINAL",
		"LB={\"content\":[{\"id\":",
		"RB=,\"applicant\"",
		SEARCH_FILTERS,
		LAST);

	web_custom_request("/api/ticket/",
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC01_T06_ Description_and_approving",LR_AUTO);
	
	lr_start_transaction("UC01_T07_Logout");

	web_url("/api/logout", 
		"URL=http://{host}:{port}/api/logout", 
		"Resource=0", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/login", 
		"URL=http://{host}:{port}/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T07_Logout",LR_AUTO);
	
	rc = lrvtc_connect(VtsServer, nPort, VTOPT_KEEP_ALIVE);
	rc = lrvtc_send_message("New", "{ID_FINAL}");
	rc = lrvtc_disconnect();
	return 0;
}