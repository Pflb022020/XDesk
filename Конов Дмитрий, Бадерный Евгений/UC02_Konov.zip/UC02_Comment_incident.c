UC02_Comment_incident()
{
	lr_start_transaction("UC02_T01_Entrance");
	
	web_url("login", 
		"URL=http://{host}:{port}/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t3.inf", 
		"Mode=HTML",
		LAST);
	
	lr_end_transaction("UC02_T01_Entrance", LR_AUTO);
	
	lr_start_transaction("UC02_T02_Logging_in");

	web_submit_data("/api/login", 
		"Action=http://{host}:{port}/api/login", 
		"Method=POST", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);

	web_url("/", 
		"URL=http://{host}:{port}/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t5.inf", 
		"Mode=HTML",
		LAST);

	web_url("/api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/user/info", 
		"URL=http://{host}:{port}/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/task/countByState/4", 
		"URL=http://{host}:{port}/api/task/countByState/4", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/task/countByState/", 
		"URL=http://{host}:{port}/api/task/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_save_param_ex(
		"ParamName=id",
		"LB=\"id\":",
		"RB=,\"parentId\"",
		"Ordinal=ALL",
		SEARCH_FILTERS,
		LAST);

	web_custom_request("/api/task/", 
		"URL=http://{host}:{port}/api/task/?state=1&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);
	
	lr_end_transaction("UC02_T02_Logging_in",LR_AUTO);
	
	lr_save_string(lr_paramarr_random("id"), "idRandom");
	
	lr_start_transaction("UC02_T03_Choose_incident");

	web_url("/api/task/{idRandom}", 
		"URL=http://{host}:{port}/api/task/{idRandom}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/{idRandom}/comment/", 
		"URL=http://{host}:{port}/api/ticket/{idRandom}/comment/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC02_T03_Choose_incident",LR_AUTO);

	lr_start_transaction("UC02_T04_Create_comment");

	web_custom_request("/api/ticket/{idRandom}/comment/", 
		"URL=http://{host}:{port}/api/ticket/{idRandom}/comment/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"text\":\"{commentary}\",\"files\":[]}", 
		LAST);

	web_url("/api/ticket/{idRandom}/comment/", 
		"URL=http://{host}:{port}/api/ticket/{idRandom}/comment/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC02_T04_Create_comment",LR_AUTO);

	lr_start_transaction("UC02_T05_Logout");

	web_url("/api/logout", 
		"URL=http://{host}:{port}/api/logout", 
		"Resource=0", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/login", 
		"URL=http://{host}:{port}/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC02_T05_Logout",LR_AUTO);

	return 0;
}