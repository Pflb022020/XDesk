﻿UC03_by_Eugene_Badyorniy()
{
	lr_start_transaction("UC03_T01_Entrance");

	web_url("/login", 
		"URL=http://{host}:{port}/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_T01_Entrance", LR_AUTO);
	
	lr_start_transaction("UC03_T02_Logging_in");

	web_submit_data("/api/login", 
		"Action=http://{host}:{port}/api/login", 
		"Method=POST", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);

	web_url("/", 
		"URL=http://{host}:{port}/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t6.inf", 
		"Mode=HTML",
		LAST);

	web_url("/api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/user/info", 
		"URL=http://{host}:{port}/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"Resource=0", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("/api/ticket/", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC03_T02_Logging_in",LR_AUTO);

	lr_start_transaction("UC03_T03_Going_to_tasks_list");

	web_reg_save_param_ex(
		"ParamName=id",
		"LB={\"id\":",
		"RB=,\"applicant\"",
		"Ordinal=ALL",
		SEARCH_FILTERS,
		LAST);

	web_custom_request("/api/ticket", 
		"URL=http://{host}:{port}/api/ticket/?state=1&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_save_string(lr_paramarr_random("id"), "idr");
	
	lr_end_transaction("UC03_T03_Going_to_tasks_list",LR_AUTO);

	lr_start_transaction("UC03_T04_Picking_a_task");

	web_custom_request("/api/ticket/{idr}", 
		"URL=http://{host}:{port}/api/ticket/{idr}", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/{idr}/comment/", 
		"URL=http://{host}:{port}/api/ticket/{idr}/comment/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_T04_Picking_a_task",LR_AUTO);

	lr_start_transaction("UC03_T05_Approving_completion");

	web_custom_request("/api/ticket/{idr}/solve/", 
		"URL=http://{host}:{port}/api/ticket/{idr}/solve/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("/", 
		"URL=http://{host}:{port}/", 
		"Resource=0", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/user/info", 
		"URL=http://{host}:{port}/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"Resource=0", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("/api/ticket/", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	web_custom_request("/api/ticket", 
		"URL=http://{host}:{port}/api/ticket/?state=1&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC03_T05_Approving_completion",LR_AUTO);

	lr_start_transaction("UC03_T06_Logout");

	web_url("/api/logout", 
		"URL=http://{host}:{port}/api/logout", 
		"Resource=0", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/login", 
		"URL=http://{host}:{port}/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_T06_Logout",LR_AUTO);

	return 0;
}