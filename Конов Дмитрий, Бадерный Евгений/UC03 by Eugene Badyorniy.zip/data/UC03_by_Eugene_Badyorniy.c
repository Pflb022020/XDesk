UC03_by_Eugene_Badyorniy()
{

	web_url("success.txt", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	lr_think_time(4);

	web_url("success.txt_2", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("success.txt_3", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t3.inf", 
		LAST);

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(5);

	web_url("login", 
		"URL=http://192.168.14.54:9433/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		"Url=/tpl/login/login.dust", ENDITEM, 
		"Url=/images/logo_2.png", ENDITEM, 
		"Url=/css/fonts/material_icons/MaterialIcons-Regular.woff2", "Referer=http://192.168.14.54:9433/css/core/material_icons.css", ENDITEM, 
		LAST);

	lr_start_transaction("UC03_T02_Logging_in");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(25);

	web_submit_data("login_2", 
		"Action=http://192.168.14.54:9433/api/login", 
		"Method=POST", 
		"Referer=http://192.168.14.54:9433/login", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value=director", ENDITEM, 
		"Name=password", "Value=123", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);

	web_add_cookie("currentCompany=0; DOMAIN=192.168.14.54");

	web_add_cookie("currentUser=director; DOMAIN=192.168.14.54");

	web_add_cookie("PFLB.pre.login.link=null; DOMAIN=192.168.14.54");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("192.168.14.54:9433", 
		"URL=http://192.168.14.54:9433/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.14.54:9433/login", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/js/core/jqueryformplugin.js?_=1582289725963", ENDITEM, 
		"Url=/director/wrapper/wrapper.dust", ENDITEM, 
		"Url=/director/wrapper/wrapper.js", ENDITEM, 
		"Url=/director/tickets/tickets.dust", ENDITEM, 
		"Url=/director/tickets/tickets.js", ENDITEM, 
		"Url=/director/ticket/ticket.dust", ENDITEM, 
		"Url=/director/ticket/ticket.js", ENDITEM, 
		"Url=/images/logo-5ka.png", ENDITEM, 
		"Url=/images/custom.png", ENDITEM, 
		"Url=/tpl/comment.dust", ENDITEM, 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("checkLogin", 
		"URL=http://192.168.14.54:9433/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("info", 
		"URL=http://192.168.14.54:9433/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/4", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("DNT");

	web_revert_auto_header("X-Requested-With");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("ticket", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("UC03_T02_Logging_in",LR_AUTO);

	lr_start_transaction("UC03_T03_Going_to_tasks_list");

	web_add_cookie("filterSetting=%7B%22page%22%3A%22http%3A%2F%2F192.168.14.54%3A9433%2F%23tickets%3Fstate%3Dopened%26page%3D1%22%2C%22smho%22%3Anull%2C%22dateStart%22%3A%22%22%2C%22dateEnd%22%3A%22%22%2C%22cat1%22%3Anull%2C%22cat2%22%3Anull%2C%22cat3%22%3Anull%2C%22cat4%22%3Anull%2C%22theme%22%3Anull%2C%22overdue%22%3Afalse%2C%22filters%22%3A%7B%22newCheckbox%22%3Afalse%2C%22appointedCheckbox%22%3Afalse%2C%22performedCheckbox%22%3Atrue%2C%22controlCheckbox%22%3Afalse%7D%7D; DOMAIN=192.168.14.54");

	web_add_auto_header("DNT", 
		"1");

	lr_think_time(14);

	web_custom_request("ticket_2", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=1&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC03_T03_Going_to_tasks_list",LR_AUTO);

	lr_start_transaction("UC03_T04_Picking_a_task");

	web_custom_request("152224", 
		"URL=http://192.168.14.54:9433/api/ticket/152224", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_url("comment", 
		"URL=http://192.168.14.54:9433/api/ticket/152224/comment/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_T04_Picking_a_task",LR_AUTO);

	lr_think_time(57);

	lr_start_transaction("UC03_T05_Approving_completion");

	web_custom_request("solve", 
		"URL=http://192.168.14.54:9433/api/ticket/152224/solve/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("DNT");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("192.168.14.54:9433_2", 
		"URL=http://192.168.14.54:9433/", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt", "Referer=", ENDITEM, 
		"Url=/js/core/jqueryformplugin.js?_=1582289861429", ENDITEM, 
		"Url=/director/wrapper/wrapper.dust", ENDITEM, 
		"Url=/director/wrapper/wrapper.js", ENDITEM, 
		"Url=/director/tickets/tickets.dust", ENDITEM, 
		"Url=/director/tickets/tickets.js", ENDITEM, 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("checkLogin_2", 
		"URL=http://192.168.14.54:9433/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_url("info_2", 
		"URL=http://192.168.14.54:9433/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4_2", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/4", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState_2", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState_3", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("ticket_3", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	web_custom_request("ticket_4", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=1&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC03_T05_Approving_completion",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("UC03_T06_Logout");

	web_url("logout", 
		"URL=http://192.168.14.54:9433/api/logout", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("sessionExpired=false; DOMAIN=192.168.14.54");

	web_revert_auto_header("X-Requested-With");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("login_3", 
		"URL=http://192.168.14.54:9433/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_T06_Logout",LR_AUTO);

	return 0;
}