UC03_Closing_the_request()
{
	lr_start_transaction("UC03_T01_Entrance");

	web_url("/login", 
		"URL=http://{host}:{port}/login", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html",
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("UC03_T01_Entrance", LR_AUTO);
	
	lr_start_transaction("UC02_T02_Logging_in");

	web_submit_data("/api/login", 
		"Action=http://{host}:{port}/api/login", 
		"Method=POST", 
		"TargetFrame=",
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);

	web_url("/", 
		"URL=http://{host}:{port}/", 
		"TargetFrame=", 
		"Resource=0",
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/user/info", 
		"URL=http://{host}:{port}/api/user/info", 
		"TargetFrame=", 
		"Resource=0", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/4", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0",
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"TargetFrame=", 
		"Resource=0", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC02_T02_Logging_in",LR_AUTO);
	
	lr_start_transaction("UC03_T03_Going_to_tasks_list");
	
	web_reg_save_param_ex(
		"ParamName=id",
		"LB=\"id\":",
		"RB=,\"applicant\"",
		"Ordinal=ALL",
		SEARCH_FILTERS,
		LAST);
	
	web_custom_request("/api/ticket/", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"Snapshot=t67.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8",
		LAST);

	lr_end_transaction("UC03_T03_Going_to_tasks_list",LR_AUTO);
	
	lr_save_string(lr_paramarr_random("id"), "idRandom");
	
	lr_start_transaction("UC03_T04_Picking_a_task");

	web_custom_request("/api/ticket/{idRandom}", 
		"URL=http://{host}:{port}/api/ticket/{idRandom}", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/{idRandom}/comment/", 
		"URL=http://{host}:{port}/api/ticket/{idRandom}/comment/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_T04_Picking_a_task",LR_AUTO);

	lr_start_transaction("UC03_T05_Approving_completion");

	web_custom_request("/api/ticket/{idRandom}/solve/", 
		"URL=http://{host}:{port}/api/ticket/{idRandom}/solve/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json",
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("/", 
		"URL=http://{host}:{port}/", 
		"TargetFrame=", 
		"Resource=0", 
		"Snapshot=t45.inf", 
		"Mode=HTML",
		LAST);

	web_url("/api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"TargetFrame=", 
		"Resource=0",
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/4", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0",
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		LAST);
	
	web_custom_request("/api/ticket/?", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0",
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	web_url("/api/ticket/countByState/", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"TargetFrame=", 
		"Resource=0",
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_T05_Approving_completion",LR_AUTO);

	lr_start_transaction("UC03_T06_LogOut");

	web_custom_request("/api/ticket/", 
		"URL=http://{host}:{port}/api/ticket/?state=1&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	web_url("/api/logout", 
		"URL=http://{host}:{port}/api/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://{host}:{port}/", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_T06_LogOut",LR_AUTO);

	return 0;
}