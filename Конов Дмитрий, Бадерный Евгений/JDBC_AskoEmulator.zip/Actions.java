import lrapi.lr;
import lrapi.vts.Lrvtc;
import lrapi.vts.Constants;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;

public class Actions {
    public int init() throws Throwable {
        DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
        return 0;
    }

    public int action() throws Throwable {
        String VtsServer = "192.168.14.62";
        String ID = "";
        String login = "c##x5";
        String password = "c##x5";
        String jdbc = "jdbc:oracle:thin:@192.168.14.53:1522:orcl";
        int nPort = 3999;
        int rc = 1; // 1 = FALSE

        rc = Lrvtc.connect(VtsServer, nPort, 0);

        try {

            lr.start_transaction("EM_1_VTC_CONNECT");
            if (rc == 0) {
                if (Lrvtc.retrieve_message("New") == 0) {
                    lr.log_message("rc = " + rc + "\n");
                    ID = lr.eval_string("{New}");
                    lr.log_message("ID = " + ID + "\n");
                } else {
                    lr.log_message("VTS message is not exist" + "\n");
                }
            } else {
                lr.log_message("Failed connection to VTS Server" + "\n");
            }
            lr.end_transaction("EM_1_VTC_CONNECT", lr.PASS);

        } catch (Exception eVTS_CONNECT) {
            lr.end_transaction("EM_1_VTC_CONNECT", lr.FAIL);
            lr.log_message("VTC CONNECTION failed" + "\n");

        }

        try (Connection connection = DriverManager.getConnection(jdbc, login, password); Statement st = connection.createStatement();) {

            try {
                lr.start_transaction("EM_2_DB_UPDATE");
                st.executeUpdate("UPDATE TICKET SET STATE_ID = 1 WHERE ID = " + ID);
                lr.end_transaction("EM_2_DB_UPDATE", lr.PASS);
            } catch (Exception eDB_UPDATE) {
                lr.end_transaction("EM_2_DB_UPDATE", lr.FAIL);
                lr.log_message("DB UPDATE operation failed");
            }

            try {
                lr.start_transaction("EM_3_DB_INSERT");
                st.executeUpdate("INSERT INTO TASK (id, ticket_id, state_id, client_id, guid, header, text, CREATE_DATE, external_system) SELECT ID, ID, state_id, '106', GUID, HEADER, TEXT, CREATE_DATE, 'ASKO' FROM TICKET WHERE ID=" + ID);
                lr.log_message("DB TASK has UPDATED");
                lr.end_transaction("EM_3_DB_INSERT", lr.PASS);
            } catch (Exception eINSERT) {
                lr.end_transaction("EM_3_DB_INSERT", lr.FAIL);
                lr.log_message("DB INSERT operation failed");
            }
        } catch (Exception e) {
            lr.log_message("Connection fail!");
        }

        return 0;
    }


    public int end() throws Throwable {
        return 0;
    }
}