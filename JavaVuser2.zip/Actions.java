/*
 * LoadRunner Java script. (Build: _build_number_)
 * 
 * Script Description: 
 *                     
 */

import lrapi.lr;
import lrapi.vts.Lrvtc;
import lrapi.vts.Constants;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;



public class Actions
{

	public int init() throws Throwable {
		
		Class.forName("oracle.jdbc.OracleDriver");
		DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		
		return 0;
	}//end of init


	public int action() throws Throwable {
		
		String VtsServer = "192.168.14.62";
    	String ID = "";
    	String login = "c##x5";
    	String password = "c##x5";
    	String jdbc = "jdbc:oracle:thin:@192.168.14.53:1522:orcl";
    	int nPort = 3999;
    	int rc = 1;
    	
		rc = Lrvtc.connect(VtsServer, nPort, 0);
		
		try {
			if (rc == 0){
				Lrvtc.retrieve_message("New");
				lr.log_message("retrieve_message rc=" + rc + "\n");
				ID = lr.eval_string("{New}");
				lr.log_message("rc = " + ID + "\n");					
			}
			else{
				lr.log_message("Faild connection to VTC");	
			}

     	}catch (Exception e) {lr.log_message("Failed connection to Lrvtc.connect" + "\n");}
	
		try {
			Connection connection = DriverManager.getConnection(jdbc, login, password);
			Statement st = connection.createStatement();
				
	 		st.executeUpdate("UPDATE TICKET SET STATE_ID = 1 WHERE ID = " + ID);
			lr.log_message("DB TICKET has UPDATED");
	  		st.executeUpdate("INSERT INTO TASK (id, ticket_id, state_id, client_id, guid, header, text, CREATE_DATE, external_system) SELECT ID, ID, state_id, '106', GUID, HEADER, TEXT, CREATE_DATE, 'ASKO' FROM TICKET WHERE ID=" + ID);
	 		lr.log_message("DB TASK has UPDATED");
			
			st.close();
	     	connection.close();
     	
		}catch (Exception e1) {lr.log_message("Failed connection to DB Oracle" + "\n");}
		
		return 0;
	}//end of action


	public int end() throws Throwable {
		return 0;
	}//end of end
}
