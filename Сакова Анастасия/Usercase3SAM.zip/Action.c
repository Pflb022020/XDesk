// random_Gen(int length)
//{
//	char buffer[32];
//	int i,r;
//	char c;
//
//	for (i = 0; i<length; i++)
//	{
//		r = rand() %25 +65;
//		c = (char)r;
//		buffer[i] = c;
//	}
//	lr_save_string(buffer, "Random_Param");
//	
//	lr_log_message("Its log time");
//	lr_log_message(buffer);
//	
//	return 0;
//}

Action()
{
	///////////////////////////���������� ����������
	char buffer[32];
	/////////////////////////////////////////////////////���� �� ����
	lr_start_transaction("UC02_T01_Entrance");

	web_add_header("Upgrade-Insecure-Requests", "1");

	web_url("login_2", 
		"URL=http://192.168.14.54:9433/login", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC02_T01_Entrance",LR_AUTO);
	
	/////////////////////////////////////////////////////���� � ������� ������
	lr_start_transaction("UC02_T02_Logging_in");
	
	lr_think_time( rand() %10);
	
	web_submit_data("login_3", 
		"Action=http://192.168.14.54:9433/api/login", 
		"Method=POST", 
		"TargetFrame=", 
		"Referer=http://192.168.14.54:9433/login", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={Username}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);

	lr_end_transaction("UC02_T02_Logging_in",LR_AUTO);

	
	
	/////////////////////////////////////////////////////������� ��������

	lr_start_transaction("UC02_�03_Choose_incident");
	
	web_reg_save_param_regexp(
		"ParamName=Incident_ID",
		"RegExp=,\"parentId\":(.*?),\".*?�����������",
		"Group=1",
		"Ordinal=ALL",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=Incid_ID",
		"LB=,\"parentId\":",
		"RB=,\"externalId\":",
		"Ordinal=ALL",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
	
	
	web_add_header("Origin",
		"http://192.168.14.54:9433");
	
	web_custom_request("web_custom_request",
		"URL=http://192.168.14.54:9433/api/task/?state=1&page=0&size=100",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Snapshot=t32.inf", 
		"Mode=HTML",
		"Body=",
		LAST);

 lr_save_string(lr_paramarr_random("Incid_ID"),"Random_Incident_Id");  
 
 	//lr_think_time( rand() %10);
	
	lr_end_transaction("UC02_�03_Choose_incident",LR_AUTO);
	
	
	/////////////////////////////////////////////////////�������� �����������

	lr_start_transaction("UC02_�04_Create_comment");

	//random_Gen(10);
	
	//lr_output_message("Name = %s", lr_eval_string("{Random_Param}"));
	
	lr_think_time( rand() %10+5);
	
	lr_save_string("DID YOOU MISS ME", "Random_Param");
	
	web_custom_request("comment", 
		"URL=http://192.168.14.54:9433/api/ticket/{Random_Incident_Id}/comment/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={\"text\":\"{Random_Param}?\",\"files\":[]}", 

		LAST);

	//lr_start_transaction("ok");

	//lr_end_transaction("ok",LR_AUTO);
	
	
	lr_end_transaction("UC02_�04_Create_comment",LR_AUTO);
	
	/////////////////////////////////////////////////////����� �� ������� ������

	lr_start_transaction("UC02_�05_Logout");

	web_url("logout", 
		"URL=http://192.168.14.54:9433/api/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC02_�05_Logout",LR_AUTO);

	return 0;
}