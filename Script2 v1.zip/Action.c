Action()
{
	
	lr_start_transaction("UC02_T01_Entrance");

	web_url("login", 
		"URL=http://192.168.14.54:9433/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		EXTRARES,  
		LAST);
	

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_url("RootDevice.xml", 
		"URL=http://192.168.2.109:60855/RootDevice.xml", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		EXTRARES, 
		LAST);
	
	
	lr_end_transaction("UC02_T01_Entrance",LR_AUTO);
	lr_start_transaction("UC02_T02_Logging_in");


	web_submit_data("login_2", 
		"Action=http://192.168.14.54:9433/api/login", 
		"Method=POST", 
		"Referer=http://192.168.14.54:9433/login", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={Login}", ENDITEM, 
		"Name=password", "Value=123", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);


	web_url("192.168.14.54:9433", 
		"URL=http://192.168.14.54:9433/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.14.54:9433/login", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/js/core/jqueryformplugin.js?_=1582186031431", ENDITEM, 
		"Url=/engineer/wrapper/wrapper.dust", ENDITEM, 
		"Url=/engineer/wrapper/wrapper.js", ENDITEM, 
		"Url=/css/fonts/roboto/Roboto-Bold.woff2", "Referer=http://192.168.14.54:9433/css/core/materialize.min.css", ENDITEM, 
		"Url=/css/fonts/roboto/Roboto-Medium.woff2", "Referer=http://192.168.14.54:9433/css/core/materialize.min.css", ENDITEM, 
		"Url=/engineer/tickets/tickets.dust", ENDITEM, 
		"Url=/engineer/tickets/tickets.js", ENDITEM, 
		"Url=/css/fonts/roboto/Roboto-Light.woff2", "Referer=http://192.168.14.54:9433/css/core/materialize.min.css", ENDITEM, 
		"Url=/engineer/tasks/tasks.dust", ENDITEM, 
		"Url=/engineer/tasks/tasks.js", ENDITEM, 
		"Url=/engineer/task/task.dust", ENDITEM, 
		"Url=/engineer/task/task.js", ENDITEM, 
		"Url=/images/logo-5ka.png", ENDITEM, 
		"Url=/tpl/support/ticketComment.dust", ENDITEM, 
		LAST);


	web_url("checkLogin", 
		"URL=http://192.168.14.54:9433/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_url("info", 
		"URL=http://192.168.14.54:9433/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/4", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("ticket", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC02_T02_Logging_in",LR_AUTO);

	lr_start_transaction("UC02_�03_Choose_first_incidennt");

	web_url("countByState_2", 
		"URL=http://192.168.14.54:9433/api/task/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_save_param_json(
		"ParamName=task_id_raw",
		"QueryString=$.content[:].id",
		"SelectAll=Yes",
		SEARCH_FILTERS,
		LAST);

	
	web_custom_request("task", 
		"URL=http://192.168.14.54:9433/api/task/?state=1&page=0&size=2000", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_param_sprintf("task_id","%s",lr_paramarr_random("task_id_raw"));
	
	web_url("{task_id}", 
		"URL=http://192.168.14.54:9433/api/task/{task_id}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_url("checkLogin_2", 
		"URL=http://192.168.14.54:9433/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_url("comment", 
		"URL=http://192.168.14.54:9433/api/ticket/{task_id}/comment/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC02_�03_Choose_first_incidennt",LR_AUTO);

	lr_start_transaction("UC02_�04_Create _a_comment_on_incident");


	web_custom_request("comment_2", 
		"URL=http://192.168.14.54:9433/api/ticket/{task_id}/comment/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={\"text\":\"{Comment}\",\"files\":[]}", 
		LAST);

	web_url("comment_3", 
		"URL=http://192.168.14.54:9433/api/ticket/{task_id}/comment/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC02_�04_Create _a_comment_on_incident",LR_AUTO);
	

	lr_user_data_point(lr_eval_string("{FreeMemory}"), atoi(lr_eval_string("{FreeMem}")));


	return 0;
}