UC02_Create_comment()
{
	
	lr_start_transaction("UC02_Create_Comment");
	
		lr_start_sub_transaction("UC02_T01_Entrance", "UC02_Create_Comment");
	
			web_url("/login", 
				"URL=http://{host_port}/login", 
				"Resource=0", 
				"RecContentType=text/html", 
				"Snapshot=t1.inf", 
				"Mode=HTTP", 
				LAST);
	
		lr_end_sub_transaction("UC02_T01_Entrance",LR_AUTO);

	
		lr_start_sub_transaction("UC02_T02_Logging_in", "UC02_Create_Comment");
	
			web_submit_data("/api/login", 
				"Action=http://{host_port}/api/login", 
				"Method=POST", 
				"Snapshot=t2.inf", 
				"Mode=HTTP", 
				ITEMDATA, 
				"Name=login", "Value={login}", ENDITEM, 
				"Name=password", "Value={password}", ENDITEM, 
				"Name=rememberMe", "Value=false", ENDITEM, 
				LAST);
		
			web_url("/", 
				"URL=http://{host_port}/", 
				"Resource=0", 
				"RecContentType=text/html", 
				"Snapshot=t3.inf", 
				"Mode=HTTP", 
				LAST);
		
			web_url("/api/checkLogin", 
				"URL=http://{host_port}/api/checkLogin", 
				"Resource=0", 
				"RecContentType=application/json", 
				"Snapshot=t4.inf", 
				"Mode=HTTP", 
				LAST);
		
			web_url("/api/user/info", 
				"URL=http://{host_port}/api/user/info", 
				"Resource=0", 
				"RecContentType=application/json",  
				"Snapshot=t5.inf", 
				"Mode=HTTP", 
				LAST);
		
			web_url("/api/ticket/countByState/4", 
				"URL=http://{host_port}/api/ticket/countByState/4", 
				"Resource=0",  
				"Snapshot=t6.inf", 
				"Mode=HTTP", 
				LAST);
		
		
			web_url("/api/ticket/countByState/", 
				"URL=http://{host_port}/api/ticket/countByState/", 
				"Resource=0", 
				"RecContentType=application/json", 
				"Snapshot=t7.inf", 
				"Mode=HTTP", 
				LAST);
		
			web_custom_request("/api/ticket/?state=-1,0,1,5&page=0&size=10", 
				"URL=http://{host_port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
				"Method=GET", 
				"Resource=0", 
				"RecContentType=application/json", 
				"Snapshot=t8.inf", 
				"Mode=HTTP", 
				"EncType=application/json; charset=utf-8", 
				LAST);
	
		lr_end_sub_transaction("UC02_T02_Logging_in",LR_AUTO);
	

		lr_start_sub_transaction("UC02_�03_Choose_incident", "UC02_Create_Comment");
	
			web_url("/api/task/countByState/", 
				"URL=http://{host_port}/api/task/countByState/", 
				"Resource=0", 
				"RecContentType=application/json", 
				"Snapshot=t9.inf", 
				"Mode=HTTP", 
				LAST);
			
			web_reg_save_param_ex(
			"ParamName=id",
			"LB=\"id\":",
			"RB=,\"parentId\"",
			"Ordinal=ALL",
			SEARCH_FILTERS,
			LAST);
		
			web_custom_request("/api/task/?state=1&page=0&size=10", 
				"URL=http://{host_port}/api/task/?state=1&page=0&size=10", 
				"Method=GET", 
				"Resource=0", 
				"RecContentType=application/json", 
				"Snapshot=t10.inf", 
				"Mode=HTTP", 
				"EncType=application/json; charset=utf-8", 
				LAST);
		
			lr_save_string(lr_paramarr_random("id"), "random_id");
		
			web_url("/api/task/...", 
				"URL=http://{host_port}/api/task/{random_id}", 
				"Resource=0", 
				"RecContentType=application/json", 
				"Snapshot=t11.inf", 
				"Mode=HTTP", 
				LAST);
		
			web_url("/api/checkLogin", 
				"URL=http://{host_port}/api/checkLogin", 
				"Resource=0", 
				"RecContentType=application/json", 
				"Snapshot=t12.inf", 
				"Mode=HTTP", 
				LAST);
		
			web_url("/api/ticket/.../comment/", 
				"URL=http://{host_port}/api/ticket/{random_id}/comment/", 
				"Resource=0", 
				"RecContentType=application/json", 
				"Snapshot=t13.inf", 
				"Mode=HTTP", 
				LAST);
	
		lr_end_sub_transaction("UC02_�03_Choose_incident",LR_AUTO);
	

		lr_start_sub_transaction("UC02_�04_Create_comment", "UC02_Create_Comment");
		
			web_custom_request("/api/ticket/.../comment/", 
				"URL=http://{host_port}/api/ticket/{random_id}/comment/", 
				"Method=POST", 
				"Resource=0", 
				"RecContentType=application/json", 
				"Snapshot=t14.inf", 
				"Mode=HTTP", 
				"EncType=application/json; charset=UTF-8", 
				"Body={\"text\":\"{comment}\",\"files\":[]}", 
				LAST);
		
			web_url("/api/ticket/.../comment/", 
				"URL=http://{host_port}/api/ticket/{random_id}/comment/", 
				"Resource=0", 
				"RecContentType=application/json", 
				"Snapshot=t15.inf", 
				"Mode=HTTP", 
				LAST);
	
		lr_end_sub_transaction("UC02_�04_Create_comment",LR_AUTO);
	

		lr_start_sub_transaction("UC02_�05_Logout", "UC02_Create_Comment");
	
			web_url("/api/logout", 
				"URL=http://{host_port}/api/logout", 
				"Resource=0",  
				"Snapshot=t16.inf", 
				"Mode=HTTP", 
				LAST);
			
			web_url("/login", 
				"URL=http://{host_port}/login", 
				"Resource=0", 
				"RecContentType=text/html", 
				"Snapshot=t17.inf", 
				"Mode=HTTP", 
				LAST);
	
		lr_end_sub_transaction("UC02_�05_Logout",LR_AUTO);
		
	lr_end_transaction("UC02_Create_Comment",LR_AUTO);

	return 0;
}