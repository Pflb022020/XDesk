UC03_Delete_Task()
{
	lr_start_transaction("UC03_Delete_Task");
	
		lr_start_sub_transaction("UC03_T01_Entrance", "UC03_Delete_Task");
	
			web_url("/login", 
				"URL=http://{host_port}/login",  
				"Snapshot=t1.inf",  
				LAST);
	
		lr_end_sub_transaction("UC03_T01_Entrance",LR_AUTO);
	
		lr_start_sub_transaction("UC03_T02_Logging_in", "UC03_Delete_Task");
		
			web_submit_data("/api/login", 
				"Action=http://{host_port}/api/login", 
				"Method=POST",  
				"Snapshot=t2.inf",  
				ITEMDATA, 
				"Name=login", "Value={login}", ENDITEM, 
				"Name=password", "Value={password}", ENDITEM, 
				"Name=rememberMe", "Value=false", ENDITEM, 
				LAST);
			
			web_url("/", 
				"URL=http://{host_port}/",  
				"Snapshot=t3.inf", 
				LAST);
		
		lr_end_sub_transaction("UC03_T02_Logging_in",LR_AUTO);
	
		web_reg_save_param_regexp(
			"ParamName=id",
			"RegExp={\"id\":(\\d\{6\})",
			"Group=1",
			"Ordinal=ALL",
			SEARCH_FILTERS,
			LAST);
	
		lr_start_sub_transaction("UC03_T03_Going_to_tasks_list", "UC03_Delete_Task");
		
			web_custom_request("/api/ticket/?state=1&page=0&size=10", 
				"URL=http://{host_port}/api/ticket/?state=1&page=0&size=10", 
				"Snapshot=t4.inf",  
				LAST);
		
		lr_end_sub_transaction("UC03_T03_Going_to_tasks_list",LR_AUTO);
	
		lr_save_string(lr_paramarr_random("id"), "idCur");
	
		lr_start_sub_transaction("UC03_T04_Picking_a_task", "UC03_Delete_Task");
	
			web_custom_request("/api/ticket/....", 
				"URL=http://{host_port}/api/ticket/{idCur}", 
				"Snapshot=t5.inf", 
				LAST);
		
		lr_end_sub_transaction("UC03_T04_Picking_a_task",LR_AUTO);
		
		lr_start_sub_transaction("UC03_T05_Approving_completion", "UC03_Delete_Task");
	
			web_custom_request("/api/ticket/..../solve/", 
				"URL=http://{host_port}/api/ticket/{idCur}/solve/", 
				"Method=POST",  
				"Snapshot=t6.inf", 
				LAST);
		
		lr_end_sub_transaction("UC03_T05_Approving_completion",LR_AUTO);
	
		lr_start_sub_transaction("UC03_�06_Logout", "UC03_Delete_Task");
	
			web_url("/api/logout", 
				"URL=http://{host_port}/api/logout", 
				"Resource=0", 
				"Snapshot=t7.inf", 
				"Mode=HTTP", 
				LAST);
	
			web_url("/login", 
				"URL=http://{host_port}/login", 
				"Resource=0", 
				"RecContentType=text/html",  
				"Snapshot=t8.inf", 
				"Mode=HTTP", 
				LAST);
	
		lr_end_sub_transaction("UC03_�06_Logout",LR_AUTO);

	lr_end_transaction("UC03_Delete_Task",LR_AUTO);	
	return 0;
}