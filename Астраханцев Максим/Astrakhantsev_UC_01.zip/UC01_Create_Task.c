﻿UC01_Create_Task()
{	char* VtsHost = "192.168.14.62";
	int VtsPort = 3999;
	int rc;
	int num = -1;
	
	lr_start_transaction("UC01_Create_Task");
	
	lr_start_sub_transaction("UC01_T01_Entrance", "UC01_Create_Task");
	
		web_url("/login", 
			"URL=http://{host_port}/login", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Snapshot=t1.inf", 
			"Mode=HTML",
			LAST);
	
	lr_end_sub_transaction("UC01_T01_Entrance",LR_AUTO);

	lr_start_sub_transaction("UC01_T02_Logging_in", "UC01_Create_Task");

		web_submit_data("/api/login", 
			"Action=http://{host_port}/api/login", 
			"Method=POST", 
			"Snapshot=t2.inf", 
			"Mode=HTML", 
			ITEMDATA, 
			"Name=login", "Value={login}", ENDITEM, 
			"Name=password", "Value={password}", ENDITEM, 
			"Name=rememberMe", "Value=false", ENDITEM, 
			LAST);
	
		web_url("/", 
			"URL=http://{host_port}/", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Snapshot=t3.inf", 
			"Mode=HTML",
			LAST);
	
		web_url("/api/checkLogin", 
			"URL=http://{host_port}/api/checkLogin", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t4.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/user/info", 
			"URL=http://{host_port}/api/user/info", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t5.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/ticket/countByState/4", 
			"URL=http://{host_port}/api/ticket/countByState/4", 
			"Resource=0", 
			"Snapshot=t6.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/ticket/countByState/", 
			"URL=http://{host_port}/api/ticket/countByState/", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t7.inf", 
			"Mode=HTML", 
			LAST);
	
		web_custom_request("/api/ticket", 
			"URL=http://{host_port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
			"Method=GET", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t8.inf", 
			"Mode=HTML", 
			"EncType=application/json; charset=utf-8", 
			EXTRARES,
			LAST);

	lr_end_sub_transaction("UC01_T02_Logging_in",LR_AUTO);

	lr_start_sub_transaction("UC01_T03_Creating_of_new_accident", "UC01_Create_Task");

		web_url("/api/user/catalog/node/0/children/", 
			"URL=http://{host_port}/api/user/catalog/node/0/children/", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t9.inf", 
			"Mode=HTML", 
			LAST);

	lr_end_sub_transaction("UC01_T03_Creating_of_new_accident",LR_AUTO);

	lr_start_sub_transaction("UC01_T04_Address_of_accident", "UC01_Create_Task");

		web_reg_save_param_json(
			"ParamName=IdAdr",
			"QueryString=$..id",
			"SelectAll=Yes",
			SEARCH_FILTERS,
			LAST);
		
		web_url("/api/shops", 
			"URL=http://{host_port}/api/shops?q=&page=0", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t14.inf", 
			"Mode=HTML", 
			LAST);
		
		lr_save_string(lr_paramarr_random("IdAdr"), "IdAdrRandom");
	
		web_url("/api/user/catalog/node/0/children/", 
			"URL=http://{host_port}/api/user/catalog/node/0/children/", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t10.inf", 
			"Mode=HTML", 
			LAST);
		
		web_reg_save_param_json(
			"ParamName=case",
			"QueryString=$..parentName",
			"SelectAll=Yes",
			SEARCH_FILTERS,
			LAST);
		
		web_reg_save_param_json(
			"ParamName=id",
			"QueryString=$..services..id",
			"SelectAll=Yes",
			SEARCH_FILTERS,
			LAST);
			
		
		web_url("/api/user/catalog/treeview", 
			"URL=http://{host_port}/api/user/catalog/treeview?shopid=2", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t11.inf", 
			"Mode=HTML", 
			LAST);

	lr_end_sub_transaction("UC01_T04_Address_of_accident",LR_AUTO);

	lr_start_sub_transaction("UC01_T05_Choose_of_type_accident", "UC01_Create_Task");

		web_url("/api/user/catalog/node/179/children", 
			"URL=http://{host_port}/api/user/catalog/node/179/children/", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t12.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/user/catalog/node/179/service/", 
			"URL=http://{host_port}/api/user/catalog/node/179/service/", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t13.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/user/catalog/breadcrumbs/179", 
			"URL=http://{host_port}/api/user/catalog/breadcrumbs/179", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t14.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/inventoryNumbers", 
			"URL=http://{host_port}/api/inventoryNumbers?serviceId=2881&shopId=2", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t15.inf", 
			"Mode=HTML", LAST);

	lr_end_sub_transaction("UC01_T05_Choose_of_type_accident",LR_AUTO);

	num = rand() % lr_paramarr_len("id");
	lr_save_string(lr_paramarr_idx("case", num), "CaseRandom");
	lr_save_string(lr_paramarr_idx("id", num), "IdRandom");

	lr_start_sub_transaction("UC01_T06_ Description_and_approving", "UC01_Create_Task");

		web_custom_request("/api/ticket/", 
			"URL=http://{host_port}/api/ticket/", 
			"Method=POST", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t16.inf", 
			"Mode=HTML", 
			"EncType=application/json; charset=utf-8", 
			"BodyBinary={\"text\":\"{text}\",\"header\":\"{CaseRandom}\",\"ticketStateId\":0,\"serviceId\":\"{IdRandom}\",\"files\":[],\"inventoryNumberId\":null,\"shopId\":\"{IdAdrRandom}\"}", 
			LAST);
	
		web_url("/", 
			"URL=http://{host_port}/", 
			"Resource=0", 
			"Snapshot=t17.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/checkLogin", 
			"URL=http://{host_port}/api/checkLogin", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t18.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/user/info", 
			"URL=http://{host_port}/api/user/info", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t19.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/ticket/countByState/4", 
			"URL=http://{host_port}/api/ticket/countByState/4", 
			"Resource=0", 
			"Snapshot=t20.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/ticket/countByState/",
			"URL=http://{host_port}/api/ticket/countByState/", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t21.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/api/ticket/countByState/", 
			"URL=http://{host_port}/api/ticket/countByState/", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t22.inf", 
			"Mode=HTML", 
			LAST);
	
		web_custom_request("/api/ticket/", 
			"URL=http://{host_port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
			"Method=GET", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t23.inf", 
			"Mode=HTML", 
			"EncType=application/json; charset=utf-8", 
			LAST);
	
		web_reg_save_param_ex(
			"ParamName=ID_FINAL",
			"LB={\"content\":[{\"id\":",
			"RB=,\"applicant\"",
			SEARCH_FILTERS,
			LAST);
	
		web_custom_request("/api/ticket/",
			"URL=http://{host_port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
			"Method=GET", 
			"Resource=0", 
			"RecContentType=application/json", 
			"Snapshot=t24.inf", 
			"Mode=HTML", 
			"EncType=application/json; charset=utf-8", 
			LAST);

	lr_end_sub_transaction("UC01_T06_ Description_and_approving",LR_AUTO);
	
	lr_start_sub_transaction("UC01_T07_Logout", "UC01_Create_Task");

		web_url("/api/logout", 
			"URL=http://{host_port}/api/logout", 
			"Resource=0", 
			"Snapshot=t25.inf", 
			"Mode=HTML", 
			LAST);
	
		web_url("/login", 
			"URL=http://{host_port}/login", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Snapshot=t26.inf", 
			"Mode=HTML", 
			LAST);

	lr_end_sub_transaction("UC01_T07_Logout",LR_AUTO);
	
	rc = lrvtc_connect(VtsHost, VtsPort, VTOPT_KEEP_ALIVE);
	rc = lrvtc_send_message("New", "{ID_FINAL}");
	rc = lrvtc_disconnect();
	
	lr_end_transaction("UC01_Create_Task", LR_AUTO);
	return 0;
}