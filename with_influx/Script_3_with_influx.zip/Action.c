Action()
{

	double dur;
	char s[20];
	
	lr_start_transaction("UC03_T01_Entrance");

	web_url("/login", 
		"URL=http://{host}:{port}/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
	dur = lr_get_transaction_duration("UC03_T01_Entrance");

	lr_end_transaction("UC03_T01_Entrance",LR_AUTO);
	
	gcvt (dur, 7,  s);

	lr_save_timestamp("timestamp", "DIGITS=16",  LAST);
	lr_save_string(s, "duration1");
	
	
	lr_output_message("Duration login is %s", lr_eval_string( "{duration1}"));
	lr_output_message("Timestamp is %s", lr_eval_string( "{timestamp}000") );

	
	
	web_custom_request("postImage.jsp",
	                   "Method=POST",

    "URL=http://192.168.14.62:8086/write?db=telegraf_app", 

    "Body=xdesk,transaction=T01_Entrance response_time={duration1} {timestamp}000", 

    LAST );
	
	
	
	web_set_sockets_option("SSL_VERSION", "TLS1.2");
	
	
	lr_start_transaction("UC03_T02_Logging_in");


	web_submit_data("/api/login", 
		"Action=http://{host}:{port}/api/login", 
		"Method=POST", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={Login}", ENDITEM, 
		"Name=password", "Value={pass}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);


	web_url("/", 
		"URL=http://{host}:{port}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);


	web_url("/api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/user/info", 
		"URL=http://{host}:{port}/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/4", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("/api/ticket/", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);
	
	dur = lr_get_transaction_duration("UC03_T02_Logging_in");

	lr_end_transaction("UC03_T02_Logging_in",LR_AUTO);
	
	gcvt (dur, 7,  s);

	lr_save_timestamp("timestamp", "DIGITS=16",  LAST);
	lr_save_string(s, "duration1");
	
	
	lr_output_message("Duration login is %s", lr_eval_string( "{duration1}"));
	lr_output_message("Timestamp is %s", lr_eval_string( "{timestamp}000") );

	
	
	web_custom_request("postImage.jsp",
	                   "Method=POST",

    "URL=http://192.168.14.62:8086/write?db=telegraf_app", 

    "Body=xdesk,transaction=T02_Logging_in response_time={duration1} {timestamp}000", 

    LAST );
	
	
	lr_start_transaction("UC03_T03_Going_to_tasks_list");

	web_reg_save_param_json(
		"ParamName=task_id_raw",
		"QueryString=$.content[:].id",
		"SelectAll=Yes",
		SEARCH_FILTERS,
		LAST);
	
	web_custom_request("/api/ticket/", 
		"URL=http://{host}:{port}/api/ticket/?state=1&page=0&size=2000", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);
	
	dur = lr_get_transaction_duration("UC03_T03_Going_to_tasks_list");

	lr_end_transaction("UC03_T03_Going_to_tasks_list",LR_AUTO);
	
	
	gcvt (dur, 7,  s);

	lr_save_timestamp("timestamp", "DIGITS=16",  LAST);
	lr_save_string(s, "duration1");
	
	
	lr_output_message("Duration login is %s", lr_eval_string( "{duration1}"));
	lr_output_message("Timestamp is %s", lr_eval_string( "{timestamp}000") );

	
	
	web_custom_request("postImage.jsp",
	                   "Method=POST",

    "URL=http://192.168.14.62:8086/write?db=telegraf_app", 

    "Body=xdesk,transaction=T03_GoingTo_tasks_list response_time={duration1} {timestamp}000", 

    LAST );
	
	
	lr_param_sprintf("task_id","%s",lr_paramarr_random("task_id_raw"));
	

	lr_start_transaction("UC03_T04_Picking_a_task");

	web_custom_request("/api/ticket/{task_id}", 
		"URL=http://{host}:{port}/api/ticket/{task_id}", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("/api/ticket/{task_id}/solve/", 
		"URL=http://{host}:{port}/api/ticket/{task_id}/solve/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);
	
	dur = lr_get_transaction_duration("UC03_T04_Picking_a_task");
	
	lr_end_transaction("UC03_T04_Picking_a_task",LR_AUTO);
	
	gcvt (dur, 7,  s);

	lr_save_timestamp("timestamp", "DIGITS=16",  LAST);
	lr_save_string(s, "duration1");
	
	
	lr_output_message("Duration login is %s", lr_eval_string( "{duration1}"));
	lr_output_message("Timestamp is %s", lr_eval_string( "{timestamp}000") );

	
	
	web_custom_request("postImage.jsp",
	                   "Method=POST",

    "URL=http://192.168.14.62:8086/write?db=telegraf_app", 

    "Body=xdesk,transaction=T04_Picking_a_task response_time={duration1} {timestamp}000", 

    LAST );
	
	
	lr_start_transaction("UC03_T05_Approving_completion");
	

	web_url("/api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);


	web_custom_request("/api/ticket/", 
		"URL=http://{host}:{port}/api/ticket/?state=1&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json",  
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);
	
	dur = lr_get_transaction_duration("UC03_T05_Approving_completion");

	
	lr_end_transaction("UC03_T05_Approving_completion",LR_AUTO);
	
	
	gcvt (dur, 7,  s);

	lr_save_timestamp("timestamp", "DIGITS=16",  LAST);
	lr_save_string(s, "duration1");
	
	
	lr_output_message("Duration login is %s", lr_eval_string( "{duration1}"));
	lr_output_message("Timestamp is %s", lr_eval_string( "{timestamp}000") );

	
	
	web_custom_request("postImage.jsp",
	                   "Method=POST",

    "URL=http://192.168.14.62:8086/write?db=telegraf_app", 

    "Body=xdesk,transaction=T05_Approving_completion response_time={duration1} {timestamp}000", 

    LAST );


	lr_start_transaction("UC03_�06_Logout");

	web_url("/api/logout", 
		"URL=http://{host}:{port}/api/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);
	
	dur = lr_get_transaction_duration("UC03_�06_Logout");

	lr_end_transaction("UC03_�06_Logout",LR_AUTO);
	
	
	gcvt (dur, 7,  s);

	lr_save_timestamp("timestamp", "DIGITS=16",  LAST);
	lr_save_string(s, "duration1");
	
	
	lr_output_message("Duration login is %s", lr_eval_string( "{duration1}"));
	lr_output_message("Timestamp is %s", lr_eval_string( "{timestamp}000") );

	
	
	web_custom_request("postImage.jsp",
	                   "Method=POST",

    "URL=http://192.168.14.62:8086/write?db=telegraf_app", 

    "Body=xdesk,transaction=Logout response_time={duration1} {timestamp}000", 

    LAST );

	return 0;
}