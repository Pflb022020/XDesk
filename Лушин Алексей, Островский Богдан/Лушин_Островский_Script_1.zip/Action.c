Action()
{

	lr_start_transaction("UC01_T01_Entrance");
	
	web_url("login", 
		"URL=http://{Host}:{Port}/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	lr_end_transaction("UC01_T01_Entrance",LR_AUTO);

	lr_start_transaction("UC01_T02_Logging_in");

	web_submit_data("api/login", 
		"Action=http://{Host}:{Port}/api/login", 
		"Method=POST", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={Login}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);

	web_url("{Host}:{Port}", 
		"URL=http://{Host}:{Port}/", 
		"Resource=0", 
		"RecContentType=text/html",  
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("api/checkLogin", 
		"URL=http://{Host}:{Port}/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("api/user/info", 
		"URL=http://{Host}:{Port}/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json",  
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("api/ticket/countByState/4", 
		"URL=http://{Host}:{Port}/api/ticket/countByState/4", 
		"Resource=0", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("api/ticket/countByState", 
		"URL=http://{Host}:{Port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json",  
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("api/ticket", 
		"URL=http://{Host}:{Port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC01_T02_Logging_in",LR_AUTO);

	lr_start_transaction("UC01_T03_Creating_of_new_accident");

	web_url("api/user/catalog/node/0/children", 
		"URL=http://{Host}:{Port}/api/user/catalog/node/0/children/", 
		"Resource=0", 
		"RecContentType=application/json",  
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T03_Creating_of_new_accident",LR_AUTO);

	web_reg_save_param_json(
		"ParamName=Location_json",
		"QueryString=$.content[:].id",
		"SelectAll=Yes",
		SEARCH_FILTERS,
		LAST);

	lr_start_transaction("UC01_T04_Address_of_accident");

	web_url("api/shops", 
		"URL=http://{Host}:{Port}/api/shops?q=&page=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_param_sprintf("Location","%s",lr_paramarr_random("Location_json"));
	
	web_url("api/user/catalog/node/0/children", 
		"URL=http://{Host}:{Port}/api/user/catalog/node/0/children/", 
		"Resource=0", 
		"RecContentType=application/json",  
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);
	
	web_reg_save_param_json(
		"ParamName=Cathegory_json",
		"QueryString=$[:].children[:].children[:].id",
		"SelectAll=Yes",
		SEARCH_FILTERS,
		LAST);

	web_url("api/user/catalog/treeview", 
		"URL=http://{Host}:{Port}/api/user/catalog/treeview?shopid={Location}", 
		"Resource=0", 
		"RecContentType=application/json",  
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T04_Address_of_accident",LR_AUTO);
	
	lr_param_sprintf("Cathegory","%s",lr_paramarr_random("Cathegory_json"));

	lr_start_transaction("UC01_T05_Choose_of_type_accident");

	web_url("api/user/catalog/node/{Cathegory}/children", 
		"URL=http://{Host}:{Port}/api/user/catalog/node/{Cathegory}/children/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);
	
	web_reg_save_param_json(
		"ParamName=SubCathegory_json",
		"QueryString=$[:].id",
		"SelectAll=Yes",
		SEARCH_FILTERS,
		LAST);

	web_url("api/user/catalog/node/{Cathegory}/service", 
		"URL=http://{Host}:{Port}/api/user/catalog/node/{Cathegory}/service/", 
		"Resource=0", 
		"RecContentType=application/json",  
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_param_sprintf("SubCathegory","%s",lr_paramarr_random("SubCathegory_json"));

	web_url("api/user/catalog/breadcrumbs/{Cathegory}", 
		"URL=http://{Host}:{Port}/api/user/catalog/breadcrumbs/{Cathegory}", 
		"Resource=0", 
		"RecContentType=application/json",  
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_url("api/inventoryNumbers", 
		"URL=http://{Host}:{Port}/api/inventoryNumbers?serviceId={SubCathegory}&shopId={Location}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T05_Choose_of_type_accident",LR_AUTO);

	lr_start_transaction("UC01_T06_ Description_and_approving");

	web_custom_request("api/ticket", 
		"URL=http://{Host}:{Port}/api/ticket/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json",  
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"BodyBinary={\"text\":\"{Comment}\",\"header\":\"\\xD0\\x9E\\xD1\\x82\\xD1\\x81\\xD1\\x83\\xD1\\x82\\xD1\\x81\\xD1\\x82\\xD0\\xB2\\xD0\\xB8\\xD0\\xB5 \\xD1\\x83\\xD0\\xB1\\xD0\\xBE\\xD1\\x80\\xD0\\xBA\\xD0\\xB8 \\xD0\\xBF\\xD1\\x80\\xD0\\xB8\\xD0\\xBB\\xD0\\xB5\\xD0\\xB3\\xD0\\xB0\\xD1\\x8E\\xD1\\x89\\xD0\\xB5\\xD0\\xB9 \\xD1\\x82\\xD0\\xB5\\xD1\\x80\\xD1\\x80\\xD0\\xB8\\xD1\\x82\\xD0\\xBE\\xD1\\x80\\xD0\\xB8\\xD0\\xB8\",\"ticketStateId\":0,\"serviceId\":\"{SubCathegory}\",\"files\":[],\""
		"inventoryNumberId\":null,\"shopId\":\"{Location}\"}", 
		LAST);


	web_url("{Host}:{Port}", 
		"URL=http://{Host}:{Port}/", 
		"Resource=0",  
		"Snapshot=t20.inf", 
		"Mode=HTML",  
		LAST);

	web_url("api/checkLogin", 
		"URL=http://{Host}:{Port}/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_url("api/user/info", 
		"URL=http://{Host}:{Port}/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_url("api/ticket/countByState/4", 
		"URL=http://{Host}:{Port}/api/ticket/countByState/4", 
		"Resource=0", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_url("api/ticket/countByState", 
		"URL=http://{Host}:{Port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_url("api/ticket/countByState", 
		"URL=http://{Host}:{Port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("api/ticket", 
		"URL=http://{Host}:{Port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	web_custom_request("api/ticket", 
		"URL=http://{Host}:{Port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json",  
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC01_T06_ Description_and_approving",LR_AUTO);

	lr_start_transaction("UC01_T07_Logout");

	web_url("logout", 
		"URL=http://{Host}:{Port}/api/logout", 
		"Resource=0",  
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_url("login", 
		"URL=http://{Host}:{Port}/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T07_Logout",LR_AUTO);

	return 0;
}