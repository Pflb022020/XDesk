Action()
{

	lr_start_transaction("UC03_T01_Entrance");

	web_url("/login", 
		"URL=http://{host}:{port}/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	
	lr_end_transaction("UC03_T01_Entrance",LR_AUTO);
	
	
	lr_start_transaction("UC03_T02_Logging_in");


	web_submit_data("/api/login", 
		"Action=http://{host}:{port}/api/login", 
		"Method=POST", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={Login}", ENDITEM, 
		"Name=password", "Value={pass}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);


	web_url("/", 
		"URL=http://{host}:{port}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);


	web_url("/api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/user/info", 
		"URL=http://{host}:{port}/api/user/info", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/4", 
		"URL=http://{host}:{port}/api/ticket/countByState/4", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("/api/ticket/countByState/", 
		"URL=http://{host}:{port}/api/ticket/countByState/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("/api/ticket/", 
		"URL=http://{host}:{port}/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC03_T02_Logging_in",LR_AUTO);
	
	
	lr_start_transaction("UC03_T03_Going_to_tasks_list");

	web_reg_save_param_json(
		"ParamName=task_id_raw",
		"QueryString=$.content[:].id",
		"SelectAll=Yes",
		SEARCH_FILTERS,
		LAST);
	
	web_custom_request("/api/ticket/", 
		"URL=http://{host}:{port}/api/ticket/?state=1&page=0&size=2000", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC03_T03_Going_to_tasks_list",LR_AUTO);
	
	
	lr_param_sprintf("task_id","%s",lr_paramarr_random("task_id_raw"));
	

	lr_start_transaction("UC03_T04_Picking_a_task");

	web_custom_request("/api/ticket/{task_id}", 
		"URL=http://{host}:{port}/api/ticket/{task_id}", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("{host}:{port}/api/ticket/{task_id}/solve/", 
		"URL=http://{host}:{port}/api/ticket/{task_id}/solve/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);
	lr_end_transaction("UC03_T04_Picking_a_task",LR_AUTO);
	
	
	lr_start_transaction("UC03_T05_Approving_completion");
	

	web_url("http://{host}:{port}/api/checkLogin", 
		"URL=http://{host}:{port}/api/checkLogin", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);


	web_custom_request("/api/ticket/", 
		"URL=http://{host}:{port}/api/ticket/?state=1&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json",  
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	
	lr_end_transaction("UC03_T05_Approving_completion",LR_AUTO);


	lr_start_transaction("UC03_�06_Logout");

	web_url("/api/logout", 
		"URL=http://{host}:{port}/api/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_�06_Logout",LR_AUTO);

	return 0;
}