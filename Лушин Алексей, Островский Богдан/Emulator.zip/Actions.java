

import lrapi.lr;
import lrapi.vts.Lrvtc;
import java.util.Random;
import java.util.Date;
import lrapi.vts.Constants;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;


public class Actions
{

	public int init() throws Throwable {
		
		DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		
		return 0;
	}//end of init


	public int action() throws Throwable {
		String url_jdbc = "jdbc:oracle:thin:@192.168.14.53:1522:orcl";
		int vts_port = 3999; 
		String vts_serv = "192.168.14.62";
		String login = "c##x5";
    		String pass = "c##x5";
    		int vts_conn = 1;
    		String ID = new String();
    		String ID_Changed =  new String();
    			
    		try
    		{
    			vts_conn = Lrvtc.connect(vts_serv,vts_port,0);
    			
    			lr.start_transaction("EM_1_VTC_CONNECTION");
    			
				if (vts_conn !=1) {
    				
					if (Lrvtc.retrieve_message("New") == 0){
						ID = lr.eval_string("{New}");
						Lrvtc.send_message ( "InProgress", ID );
						lr.log_message("ID = " + ID + "\n");	
					} else {
						lr.log_message("VTS message New is not exist" + "\n");						
					}					
				}
				else{
					lr.log_message("Faild connection to VTS Server" + "\n");	
				}
    			
			lr.end_transaction("EM_1_VTC_CONNECTION", lr.PASS);
    			
   
    		}catch (Exception VTS_CONNECTION) {
    			
    				lr.end_transaction("EM_1_VTC_CONNECTION", lr.FAIL);			
				lr.log_message("VTS connection error"+"\n");
    			
    		}
    		
    		
    		Connection connection = null;
    		Statement st =null;
    		
    		try
    		{
    			connection = DriverManager.getConnection(url_jdbc, login, pass);
    			
    			st = connection.createStatement();
    			
    			
    			lr.start_transaction("EM_2_CHANGE_InProgress");
    			
    			if (Lrvtc.retrieve_message("InProgress") == 0){
    				
    				ID_Changed = lr.eval_string("{InProgress}");
    				Random r = new Random();
    				String numb = "024";
    				int State_id = numb.charAt(r.nextInt(numb.length()));
    			
    				try{
    					st.executeUpdate("UPDATE TASK SET STATE_ID = " + State_id +  "WHERE ID = " + ID_Changed);
    					if(State_id==2){
    						Date date = new Date();
    						st.executeUpdate("UPDATE TASK SET FINISH_WORKING_DATE = " + date + "WHERE ID = " + ID_Changed);
    					
    					}
    					
    				}catch (Exception DB_UPDATE) {
    				
    					lr.log_message("DB UPDATE operation failed"+"\n");
    				
    				}
    				
    			
    			}
    			
    			else{
    			
    				lr.log_message("VTS message InProgress is not exist" + "\n");
    			
    			}
    			
    			lr.end_transaction("EM_2_CHANGE_InProgress", lr.PASS);
    			
    		
    			try {
				lr.start_transaction("EM_3_DB_UPDATE");
					st.executeUpdate("UPDATE TICKET SET STATE_ID = 1 WHERE ID = " + ID);
				lr.end_transaction("EM_3_DB_UPDATE", lr.PASS);				
			} catch (Exception eDB_UPDATE){
				lr.end_transaction("EM_3_DB_UPDATE", lr.FAIL);
					lr.log_message("DB UPDATE operation failed");			
			}
					
			try {
				lr.start_transaction("EM_4_DB_INSERT");
					st.executeUpdate("INSERT INTO TASK (id, ticket_id, state_id, client_id, guid, header, text, CREATE_DATE, external_system) SELECT ID, ID, state_id, '106', GUID, HEADER, TEXT, CREATE_DATE, 'ASKO' FROM TICKET WHERE ID=" + ID);
		 			lr.log_message("DB TASK has UPDATED");	
		 		lr.end_transaction("EM_4_DB_INSERT", lr.PASS);
		 		
			} catch (Exception eINSERT){
				lr.end_transaction("EM_4_DB_INSERT", lr.FAIL);
					lr.log_message("DB INSERT operation failed");			
			}
    		 		
    			st.close();
                     connection.close();
    			
    		
    		}catch (Exception DB_CONNECTION) {
    			
    			
    					
    			lr.log_message("DB CONNECTION operation failed"+"\n");
    			st.close();
                     connection.close();
  
    			
    			
    		}
		
	    		
    		Lrvtc.disconnect( );
		
		return 0;
	}//end of action


	public int end() throws Throwable {
		return 0;
	}//end of end
}
