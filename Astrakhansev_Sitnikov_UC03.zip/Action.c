Action()
{
////////////////////////////////////////////////////////////////////	
	lr_start_transaction("UC03_T01_Entrance");

	web_url("login_2", 
		"URL=http://{ip}:{port}/login",  
		"Snapshot=t21.inf",  
		LAST);
	
	lr_think_time(5);

	lr_end_transaction("UC03_T01_Entrance",LR_AUTO);
////////////////////////////////////////////////////////////////////	
	lr_start_transaction("UC03_T02_Logging_in");
	
	//lr_save_string(lr_paramarr_random("login"), "loginCur");
	
	web_submit_data("login_3", 
		"Action=http://{ip}:{port}/api/login", 
		"Method=POST",  
		"Snapshot=t22.inf",  
		ITEMDATA, 
		"Name=login", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		LAST);
	
	web_url("{ip}:{port}", 
		"URL=http://{ip}:{port}/",  
		"Snapshot=t23.inf", 
		LAST);

	lr_think_time(5);
	
	lr_end_transaction("UC03_T02_Logging_in",LR_AUTO);
////////////////////////////////////////////////////////////////////	
	lr_start_transaction("UC03_T03_Going_to_tasks_list");

	web_reg_save_param_regexp(
		"ParamName=id",
		"RegExp={\"id\":(\\d\{6\})",
		"Group=1",
		"Ordinal=ALL",
		SEARCH_FILTERS,
		LAST);
	
	web_custom_request("ticket_2", 
		"URL=http://{ip}:{port}/api/ticket/?state=1&page=0&size=10", 
		"Snapshot=t60.inf",  
		LAST);

	lr_think_time(5);
	
	lr_end_transaction("UC03_T03_Going_to_tasks_list",LR_AUTO);
////////////////////////////////////////////////////////////////////		
	lr_start_transaction("UC03_T04_Picking_a_task");

	lr_save_string(lr_paramarr_random("id"), "idCur");

	web_custom_request("151979", 
		"URL=http://{ip}:{port}/api/ticket/{idCur}", 
		"Snapshot=t64.inf",  
		LAST);

	lr_think_time(5);
	
	lr_end_transaction("UC03_T04_Picking_a_task",LR_AUTO);
////////////////////////////////////////////////////////////////////
	lr_start_transaction("UC03_T05_Approving_completion");

	web_custom_request("solve", 
		"URL=http://{ip}:{port}/api/ticket/{idCur}/solve/", 
		"Method=POST",  
		"Snapshot=t69.inf", 
		LAST);

	lr_think_time(5);
	
	lr_end_transaction("UC03_T05_Approving_completion",LR_AUTO);
////////////////////////////////////////////////////////////////////	
	return 0;
}